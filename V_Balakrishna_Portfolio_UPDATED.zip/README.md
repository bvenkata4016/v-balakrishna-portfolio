# V Balakrishna — Personal Portfolio

A production-ready Next.js App Router portfolio for V Balakrishna, Social Media Manager & Content Creator.

## Stack
- Next.js App Router
- React
- Tailwind CSS
- Lucide React
- CSS animations / IntersectionObserver

## Run locally
```bash
npm install
npm run dev
```

Open http://localhost:3000

## Production
```bash
npm run build
npm start
```

## Image mapping
- `public/balakrishna-professional.jpg` — hero blazer portrait
- `public/balakrishna-lifestyle.jpg` — about/lifestyle photo
- `public/award-certificate.jpg` — award/certificate photo
- `public/tamashaa-logo.jpg` — Tamashaa Company logo
- `public/social-media-lead-poster.jpg` — Social Media Lead poster
- `public/manasa-youtube.jpg` — Manasa Vlogs YouTube reference
- `public/manasa-instagram.jpg` — Manasa Vlogs Instagram reference
- `public/tamashaa-profile.jpg` — Tamashaa profile reference
- `public/creative-extra.jpg` — additional supplied creative image
