 "use client";

import { useEffect, useState } from "react";
import {
  ArrowUpRight, Instagram, Youtube, Facebook, Mail, Play,
  Sparkles, Camera, Film, BarChart3, Palette, Menu, X,
  ChevronDown, ExternalLink
} from "lucide-react";

const channels = [
  {
    title: "Manasa Vlogs",
    label: "Multi-platform channel management",
    image: "/manasa-instagram.jpg",
    stats: ["45.2K YouTube", "76.9K Instagram", "31K Facebook"],
    links: [
      ["YouTube", "https://youtube.com/@manasavlogs-yz5zu"],
      ["Instagram", "https://www.instagram.com/_manasa_vlogs/"],
      ["Facebook", "https://www.facebook.com/manasa.vlogs"]
    ]
  },
  {
    title: "Balayya Vlogs",
    label: "Personal creator brand",
    image: "/balakrishna-lifestyle.jpg",
    stats: ["Travel", "Food", "Lifestyle", "Vlogs"],
    links: [["Instagram", "https://www.instagram.com/balayya_vlogs/"]]
  },
  {
    title: "Club Tamasha — GITAM",
    label: "Social Media Manager / Executive Board",
    image: "/social-media-lead-poster.jpg",
    stats: ["3+ Years", "Events", "Campaigns", "Community"],
    links: [["Instagram", "https://www.instagram.com/tamashaa.gitam/"]]
  }
];

const tools = [
  ["Adobe Premiere Pro", "Video editing", Film],
  ["CapCut", "Short-form editing", Play],
  ["VN Video Editor", "Mobile editing", Camera],
  ["Canva", "Creative design", Palette],
  ["YouTube Studio", "Channel analytics", Youtube],
  ["Meta Business Suite", "Social management", BarChart3],
  ["Instagram Analytics", "Audience insights", Instagram],
  ["Facebook Analytics", "Page insights", Facebook]
];

function Reveal({ children, className = "" }) {
  return <div className={`reveal ${className}`}>{children}</div>;
}

export default function Home() {
  const [menu, setMenu] = useState(false);
  const [active, setActive] = useState("home");

  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => e.isIntersecting && e.target.classList.add("visible"));
    }, { threshold: 0.12 });
    els.forEach(el => io.observe(el));
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    const ids = ["home", "about", "work", "skills", "contact"];
    const onScroll = () => {
      let current = "home";
      ids.forEach(id => {
        const el = document.getElementById(id);
        if (el && window.scrollY >= el.offsetTop - 180) current = id;
      });
      setActive(current);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = id => {
    setMenu(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <main>
      <header className="nav">
        <button className="brand" onClick={() => go("home")} aria-label="Home">
          <span>VB</span>
          <div>V BALAKRISHNA<small>CREATOR • STRATEGIST</small></div>
        </button>
        <nav className={menu ? "open" : ""}>
          {["home","about","work","skills","contact"].map(id => (
            <button key={id} className={active === id ? "active" : ""} onClick={() => go(id)}>
              {id === "work" ? "Work" : id[0].toUpperCase() + id.slice(1)}
            </button>
          ))}
        </nav>
        <a className="nav-cta" href="mailto:krishna3344121@gmail.com">Let’s talk <ArrowUpRight size={16}/></a>
        <button className="menu-btn" onClick={() => setMenu(!menu)} aria-label="Toggle menu">
          {menu ? <X/> : <Menu/>}
        </button>
      </header>

      <section id="home" className="hero">
        <div className="hero-glow glow-a"/>
        <div className="hero-glow glow-b"/>
        <div className="hero-copy">
          <div className="eyebrow"><span className="pulse"/> SOCIAL MEDIA • CONTENT • STORYTELLING</div>
          <h1>Turning <em>attention</em><br/>into <strong>connection.</strong></h1>
          <p>
            I’m <b>V Balakrishna</b> — a social media manager and content creator
            building communities through sharp strategy, cinematic edits and stories people remember.
          </p>
          <div className="hero-actions">
            <button className="primary" onClick={() => go("work")}>View Channels <ArrowUpRight size={18}/></button>
            <button className="secondary" onClick={() => go("contact")}>Get in Touch <Mail size={18}/></button>
          </div>
          <div className="hero-socials">
            <a href="https://www.instagram.com/balayya_vlogs/" target="_blank"><Instagram/></a>
            <a href="https://youtube.com/@manasavlogs-yz5zu" target="_blank"><Youtube/></a>
            <a href="https://www.facebook.com/manasa.vlogs" target="_blank"><Facebook/></a>
            <span/>
            <small>Based in India · Available for creative collaborations</small>
          </div>
        </div>
        <div className="hero-visual">
          <div className="orbit orbit-1"/><div className="orbit orbit-2"/>
          <div className="portrait-frame">
            <img src="/hero-blazer.jpg" alt="V Balakrishna professional portrait"/>
            <div className="portrait-tag"><Sparkles size={15}/> SOCIAL MEDIA LEAD</div>
          </div>
          <div className="floating-card card-top"><span>3+</span><small>YEARS EXPERIENCE</small></div>
          <div className="floating-card card-bottom"><span>120K+</span><small>COMMUNITY REACH</small></div>
        </div>
        <button className="scroll-cue" onClick={() => go("about")}><ChevronDown/> SCROLL TO EXPLORE</button>
      </section>

      <section id="about" className="section about">
        <Reveal className="section-head"><div><span className="kicker">01 / ABOUT</span><h2>More than a <em>creator.</em><br/>A digital storyteller.</h2></div></Reveal>
        <div className="about-grid">
          <Reveal className="about-photo">
            <img src="/balakrishna-lifestyle.jpg" alt="V Balakrishna casual lifestyle portrait"/>
            <div className="photo-note">REAL LIFE. REAL MOMENTS.<br/><b>MY WORLD, THROUGH MY LENS.</b></div>
          </Reveal>
          <Reveal className="about-text">
            <p className="lead">Content creator and social media manager with <b>3+ years</b> of experience in digital storytelling, video editing, and multi-platform channel growth.</p>
            <p>Proven track record of scaling digital communities, producing high-engagement short- and long-form content, and managing professional brand presences. From a content idea to the final frame, I care about both the story and the strategy behind it.</p>
            <div className="stats">
              <div><strong>45.2K<span>+</span></strong><small>YouTube subscribers</small></div>
              <div><strong>76.9K<span>+</span></strong><small>Instagram followers</small></div>
              <div><strong>3<span>+</span></strong><small>Years experience</small></div>
            </div>
          </Reveal>
        </div>
      </section>

      <section id="work" className="section work">
        <Reveal className="section-head">
          <div><span className="kicker">02 / SELECTED WORK</span><h2>Built for the <em>feed.</em><br/>Made to be remembered.</h2></div>
          <p>Strategy, production and publishing — bringing creative direction and measurable channel growth together.</p>
        </Reveal>
        <div className="work-grid">
          {channels.map((c, i) => (
            <Reveal key={c.title} className={`project p${i}`}>
              <div className="project-image"><img src={c.image} alt={c.title}/><div className="project-number">0{i+1}</div></div>
              <div className="project-body">
                <div><span className="kicker">{c.label}</span><h3>{c.title}</h3></div>
                <div className="project-stats">{c.stats.map(s => <span key={s}>{s}</span>)}</div>
                <div className="project-links">{c.links.map(([name,url]) => <a key={name} href={url} target="_blank">{name} <ExternalLink size={14}/></a>)}</div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="section projects-extra">
        <Reveal className="extra-grid">
          <div className="extra-copy">
            <span className="kicker">03 / CREATIVE CREDITS</span>
            <h2>Stories that move<br/><em>people.</em></h2>
            <div className="credit-list">
              <div><span>01</span><div><b>“Okka Nirnayam Okka Jeevitham”</b><p>Created and produced a short-form series focused on relatable storytelling.</p></div></div>
              <div><span>02</span><div><b>7 Short Films</b><p>Collaborated with director Vijay Reddy across seven short-film productions.</p></div></div>
              <div><span>03</span><div><b>PRERANA GITAM Techno-Cultural Fest</b><p>2nd Prize — Reel Making Competition.</p></div></div>
            </div>
          </div>
          <div className="award-card">
            <img src="/award-certificate.jpg" alt="Certificate presentation award"/>
            <div><Sparkles size={16}/> 2ND PRIZE • REEL MAKING</div>
          </div>
        </Reveal>
      </section>

      <section id="skills" className="section skills">
        <Reveal className="section-head"><div><span className="kicker">04 / TOOLKIT</span><h2>The stack behind<br/>the <em>stories.</em></h2></div><p>Creative production meets platform-native analytics and audience management.</p></Reveal>
        <div className="tool-grid">
          {tools.map(([name, desc, Icon]) => (
            <Reveal key={name} className="tool"><Icon/><div><b>{name}</b><small>{desc}</small></div><ArrowUpRight className="tool-arrow"/></Reveal>
          ))}
        </div>
      </section>

      <section className="tamashaa-banner">
        <div className="banner-art"><img src="/tamashaa-logo.jpg" alt="Tamashaa Company logo"/></div>
        <div><span className="kicker">LEADERSHIP • CLUB TAMASHAA • GITAM</span><h2>Where creativity becomes <em>community.</em></h2><p>3+ years managing social media, event promotions, digital campaigns and audience engagement as Social Media Manager / Executive Board Member.</p><a href="https://www.instagram.com/tamashaa.gitam/" target="_blank">Visit Tamashaa <ArrowUpRight/></a></div>
        <img className="banner-poster" src="/social-media-lead-poster.jpg" alt="Social Media Lead poster"/>
      </section>

      <section id="contact" className="contact">
        <div className="contact-inner">
          <span className="kicker">05 / LET’S CREATE</span>
          <h2>Have a story<br/><em>worth telling?</em></h2>
          <p>Let’s turn the idea into content people stop scrolling for.</p>
          <a className="mail" href="mailto:krishna3344121@gmail.com">krishna3344121@gmail.com <ArrowUpRight/></a>
          <div className="contact-socials">
            <a href="https://www.instagram.com/balayya_vlogs/" target="_blank"><Instagram/> Instagram</a>
            <a href="https://youtube.com/@manasavlogs-yz5zu" target="_blank"><Youtube/> YouTube</a>
            <a href="https://www.facebook.com/manasa.vlogs" target="_blank"><Facebook/> Facebook</a>
          </div>
        </div>
        <footer><span>VB</span><small>© {new Date().getFullYear()} V Balakrishna. Crafted with intent.</small><button onClick={() => go("home")}>Back to top ↑</button></footer>
      </section>
    </main>
  );
}
