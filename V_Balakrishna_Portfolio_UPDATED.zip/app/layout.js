import "./globals.css";

export const metadata = {
  title: "V Balakrishna — Social Media Manager & Content Creator",
  description: "Portfolio of V Balakrishna, social media manager and content creator.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
